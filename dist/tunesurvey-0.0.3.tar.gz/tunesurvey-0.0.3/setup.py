from distutils.core import setup
setup(
    name='tuneSurvey',
    packages=[])
