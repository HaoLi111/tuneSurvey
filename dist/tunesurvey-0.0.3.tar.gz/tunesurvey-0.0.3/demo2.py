
#

from tuneSurvey.skLists import modelList_sklearn_regressor_lite

modelList = modelList_sklearn_regressor_lite

from tuneSurvey.ts_torchLists import *

tscv = TimeSeriesSplit(n_splits=3)


import numpy as np
from tuneSurvey.tsVectorize import*
X = np.random.rand(*(1000,6))
import os
#os.mkdir("vec_search")
#os.mkdir("tsNN_search")
vsearch_modelList(modelList,X,14,tscv)
