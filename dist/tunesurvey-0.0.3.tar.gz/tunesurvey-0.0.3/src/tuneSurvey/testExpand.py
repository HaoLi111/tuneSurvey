"""Enrichment (feature engineering by expanding and vectorizing text
"""

def expand_text_blobs(df)
    
    return df

